<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php 
						if ($tbl_row) {
							foreach ($tbl_row as $data) {
							    echo $data->fname." ".$data->lname;
							}
						}
					 ?></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css')?>">
	<link href="https://fonts.googleapis.com/css2?family=Rubik:wght@500&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">

</head>
<body>


<!-- header -->
	<header>
		<div class="head">
			<a href="<?php echo base_url('key/index'); ?>"><span>Personal Information</span></a>
		</div>
	</header>	

	<!-- end of header -->

	<!-- img -->

	<div class="size">
		<img src="<?php echo base_url();?>assets/image/rodam.jpg" alt="Rodam" width="300" height="250">
	</div>

	<!-- end of img -->

	<!-- information -->
	<div class="info">
		<div class="content_info">
			<ul>
				<li><img src="<?php echo base_url()?>assets/svg/user-circle-solid.svg" alt="User" width="40" height="40" title="User"><span>
					<?php 
						if ($tbl_row) {
							foreach ($tbl_row as $data) {
							    echo $data->fname." ".$data->lname;
							}
						}
					 ?>
				</span></li>
				<li><img title="Email" src="<?php echo base_url()?>assets/svg/envelope-solid.svg" alt="User" width="40" height="40"><span>
					<?php 
						if ($tbl_row) {
							foreach ($tbl_row as $data) {
							    echo $data->email;
							}
						}
					 ?>
				</span></li><li><img title="https://www.facebook.com/Rooodaaam/" src="<?php echo base_url()?>assets/svg/facebook-square-brands.svg" alt="User" width="40" height="40" onclick="facebook();"><span>
					<?php 
						if ($tbl_row) {
							foreach ($tbl_row as $data) {
							    echo $data->facebook;
							}
						}
					 ?>
				</span></li><li><img title="Twitter" src="<?php echo base_url()?>assets/svg/twitter-brands.svg" alt="User" width="40" height="40"><span>
					<?php 
						if ($tbl_row) {
							foreach ($tbl_row as $data) {
							    echo $data->twitter;
							}
						}
					 ?>
				</span></li><li><img title="Contact" src="<?php echo base_url()?>assets/svg/phone-solid.svg" alt="User" width="40" height="40"><span>
					<?php 
						if ($tbl_row) {
							foreach ($tbl_row as $data) {
							    echo $data->phone;
							}
						}
					 ?>
				</span></li>
				<li><span style="display: block; text-align: center;">
					<?php 
						if ($tbl_row) {
							foreach ($tbl_row as $data) {
							    echo '"'.$data->motto.'"';
							}
						}
					 ?>
				</span></li>
			</ul>
		</div>
	</div>

	<!-- end of information -->



	<script type="text/javascript">
		
		function facebook(){
			window.location.href="https://www.facebook.com/Rooodaaam/";
		}

	</script>
	
</body>
</html>