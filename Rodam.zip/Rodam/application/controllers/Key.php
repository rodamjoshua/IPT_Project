<?php  


defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Key extends CI_Controller
{
    /**
     * summary
     */

    function __construct(){
    	parent:: __construct();
    	$this->load->model('db','d_data');
    }

   	function index(){
   		// echo 'Heelo';

   		$data['tbl_row'] = $this->d_data->getdata();

   		$this->load->view('sample/index',$data);
   	}
}


?>	